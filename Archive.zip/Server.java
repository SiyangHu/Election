// cd Desktop/2016-2017/2019Spring/Distributed\ Systems/Election/
// Compile with -> javac -d . *.java
// Start registry -> rmiregistry &
// Start Server with -> java -classpath . -Djava.rmi.server.codebase=file:./ Server


import java.util.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import java.net.*;
import java.beans.*;
import java.io.*;
import java.lang.*;

public class Server implements ElectionInterface{
    
    
    
    // Initialize Server's attributes
    public Server() throws RemoteException{
        super();
    }

    //For each name of the candidate (string), the number of votes (integer) is associated.
    public static ArrayList<String> voter_list = new ArrayList<String>();
    public static Hashtable<String, Integer> result_table ;

    @Override
    public String generateVotersNum() throws RemoteException{
        return UUID.randomUUID().toString();
    }
    // Making the voting results synchronized with remote
    @Override
    public synchronized Boolean vote( String name, String voter) throws RemoteException{
        try{
            // Check is a voter has voted
            boolean voted = false;
            BufferedReader input = new BufferedReader(new FileReader("voter_list.txt"));
            String line;
            FileWriter fw;
            while((line = input.readLine()) != null){
                if (line.equals(voter)){
                    voted = true;
                    System.out.println("You have already voted!");
                }
            }
            // if the voter has not voted
            if(!voted){
                fw = new FileWriter("voter_list.txt", true);
                // Writer v = new BufferedWriter(fw);
                fw.write(voter + "\n");
                fw.close();
                System.out.println("1");
                System.out.println(name);
                System.out.println("vote: " + ((int)result_table.get(name) + 1));
                result_table.put(name, (int)result_table.get(name) + 1);
                // Write to voter_list
                System.out.println("2");
                

                // Write to vote_table
                FileOutputStream fos = new FileOutputStream("result.xml");
                XMLEncoder e2 = new XMLEncoder(fos);
                e2.writeObject(result_table);
                e2.close();
                // fos.write(name.getBytes());
                // fos.write(result_table.get(name));
                // fos.close();
                return true;
            }
            // If the voter has voted
            else{
                System.out.println("You've voted. See results");
                return false;
            }
        }
        catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException: " + ex.toString());
            return false;
        }
        catch (IOException ex) {
            System.out.println("IOException");
            return false;
        }

    }
        

    
    @Override
    public Object result(String name) throws RemoteException{
        try{

        
        FileInputStream fi = new FileInputStream("result.xml");
        ObjectInputStream in = new ObjectInputStream(fi);
        Hashtable result_table = (Hashtable) in.readObject();
        return result_table.get(name);
        }
        catch (FileNotFoundException ex) {
            System.out.println("FileNotFoundException");
            return 0;
        }
        catch (IOException ex) {
            System.out.println("IOException");
            return 0;
        }
        catch (ClassNotFoundException ex) {
            System.out.println("ClassNotFoundException");
            return 0;
        }

        

    }

    public static void main(String args[]){
        try{
            System.out.println("Creating an RMI server...");
            // Create a vote remote object of the interface
            Server vote_obj = new Server();
            // Use default TCP port number, which is 1099
            ElectionInterface stub = (ElectionInterface) UnicastRemoteObject.exportObject(vote_obj,0);
            // Create a registry
            // Bind the remote object's stub in the registry
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("Hello", stub);
            System.err.println("Server ready");

        }
        catch(RemoteException e){
            System.err.println("Server exception: " + e.toString()); 
            e.printStackTrace(); 
        }
        catch(AlreadyBoundException e){
            System.err.println("Server exception: " + e.toString()); 
            e.printStackTrace(); 
        }



        result_table = new Hashtable<String, Integer>();
        
        result_table.put("Clarence Thomas", 0);
        result_table.put("Ruth Bader Ginsburg", 0);
        result_table.put("Stephen Breyer", 0);
        result_table.put("Samuel Alito", 0);
        result_table.put("Sonia Sotomayor", 0);
        result_table.put("Elena Kagan", 0);
        result_table.put("Neil Gorsuch", 0);
        result_table.put("Brett Kavanaugh", 0);
            

        // // write voter_list to xml file
        // try{
        //     FileWriter fw = new FileWriter("voter_list.txt");
        //     Writer v = new BufferedWriter(fw);
        //     v.write();
        //     v.close();
        // }
        // catch (Exception e) { 
        //     System.out.println(e); 
        // } 

         // write result_table to xml file
        try{
            FileOutputStream fos = new FileOutputStream("result.xml");
            // ObjectOutputStream out = new ObjectOutputStream(fos);
            // out.writeObject(result_table);
            // out.close();
            fos.write("Clarence Thomas".getBytes());
            fos.write(result_table.get("Clarence Thomas"));
            fos.close();
         }
        catch (Exception e) { 
            System.out.println(e); 
        } 

    }
}