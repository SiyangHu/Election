# Election
An election interface with vote and view
